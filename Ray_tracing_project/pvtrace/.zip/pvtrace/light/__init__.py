""" The light package contains modules and objects related to the generation of light 
rays and there optical properties.
"""
