from pvtrace import *
import time
import functools
import numpy as np

# Add nodes to the scene graph
from pvtrace.light.light import default_wavelength
from pvtrace.light.utils import wavelength_to_rgb

world = Node(
    name="World",
    geometry=Sphere(
        radius=10.0,
        material=Material(refractive_index=1.0),
    )
)
sphere = Node(
        name="sphere (glass)",
        geometry=Sphere(
            radius=0.5,
            material=Material(refractive_index=1.33),
        ),
        parent=world,
    )
sphere.location = (-0.03, 0.0, 2.5)
print("contains? ",sphere.geometry.contains((0,0.4999,0)))
x=0
#//// 6 len like olive.erth
len1 = Node(
    name="sphere (glass)" +  "1",
    geometry=Sphere(
        radius=0.5,
        material=Material(refractive_index=1.5),
    ),
    parent=world,
)
len1.location = (0.5, 0.0, 8)
#//////////////////////
len2 = Node(
    name="sphere (glass)" +  "2",
    geometry=Sphere(
        radius=0.5,
        material=Material(refractive_index=1.5),
    ),
    parent=world,
)
len2.location = (-0.5, 0.0, 8)
#//////////////////////
len3 = Node(
    name="sphere (glass)" +  "3",
    geometry=Sphere(
        radius=0.5,
        material=Material(refractive_index=1.5),
    ),
    parent=world,
)
len3.location = (1.5, 0.0, 7.5)
#//////////////////////
len4 = Node(
    name="sphere (glass)" +  "4",
    geometry=Sphere(
        radius=0.5,
        material=Material(refractive_index=1.5),
    ),
    parent=world,
)
len4.location = (-1.5, 0.0, 7.5)
#//////////////////////
len5 = Node(
    name="sphere (glass)" +  "5",
    geometry=Sphere(
        radius=0.5,
        material=Material(refractive_index=1.5),
    ),
    parent=world,
)
len5.location = (2.5, 0.0, 7)
#//////////////////////
len6 = Node(
    name="sphere (glass)" +  "6",
    geometry=Sphere(
        radius=0.5,
        material=Material(refractive_index=1.5),
    ),
    parent=world,
)
len6.location = (-2.5, 0.0, 7)
# Add source of photons
x=1
for i in range(1,1):
    light = Node(
        name="Light (555nm)",
        parent=world,
        light=Light(
            #wavelength=580
            # direction=functools.partial(
            #     # cone, np.radians(30)
            # )
        )
    )
    x=i*0.02
    print(x,i)
    light.translate((x, 0.1, -1))
x=1
for i in range(1,1):
    light = Node(
        name="Light (555nm)",
        parent=world,
        light=Light(
            # direction=functools.partial(
            #     # cone, np.radians(30)
            # )
        )
    )
    x=i*0.02
    print(x,i)
    light.translate((x, 0, -1))
f_wavelength=400.0
for i in range(1,2):
    f_wavelength+=20.0
    light = Node(
        name="Light (555nm)",
        parent=world,
        light=Light(
            wavelength=functools.partial(default_wavelength,f_wavelength),
            direction=functools.partial(
                cone, np.radians(10)
            )
        )
    )
    x = i * -0.02
    print(x,i)
    light.translate((x, 0, -1))



# Use meshcat to render the scene (optional)
viewer = MeshcatRenderer(open_browser=True, transparency=False, opacity=0.5, wireframe=True)
scene = Scene(world)
viewer.render(scene)
for ray in scene.emit(1):
    # ray.direction(0.08,-0.34,-0.94)
    history = photon_tracer.follow(scene, ray)
    path, events = zip(*history)
    viewer.add_ray_path(path)

# Keep the script alive until Ctrl-C (optional)
while True:
    try:
        time.sleep(0.1)
    except KeyboardInterrupt:
        break